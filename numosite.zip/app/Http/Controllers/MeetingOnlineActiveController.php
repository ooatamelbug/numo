<?php

namespace App\Http\Controllers;

use App\Models\MeetingOnlineActive;
use Illuminate\Http\Request;

class MeetingOnlineActiveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MeetingOnlineActive  $meetingOnlineActive
     * @return \Illuminate\Http\Response
     */
    public function show(MeetingOnlineActive $meetingOnlineActive)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MeetingOnlineActive  $meetingOnlineActive
     * @return \Illuminate\Http\Response
     */
    public function edit(MeetingOnlineActive $meetingOnlineActive)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MeetingOnlineActive  $meetingOnlineActive
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MeetingOnlineActive $meetingOnlineActive)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MeetingOnlineActive  $meetingOnlineActive
     * @return \Illuminate\Http\Response
     */
    public function destroy(MeetingOnlineActive $meetingOnlineActive)
    {
        //
    }
}
