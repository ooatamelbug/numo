<?php

namespace App\Http\Controllers;

use App\Models\QuestionnairesQuestionsAnwserChoices;
use Illuminate\Http\Request;

class QuestionnairesQuestionsAnwserChoicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\QuestionnairesQuestionsAnwserChoices  $questionnairesQuestionsAnwserChoices
     * @return \Illuminate\Http\Response
     */
    public function show(QuestionnairesQuestionsAnwserChoices $questionnairesQuestionsAnwserChoices)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\QuestionnairesQuestionsAnwserChoices  $questionnairesQuestionsAnwserChoices
     * @return \Illuminate\Http\Response
     */
    public function edit(QuestionnairesQuestionsAnwserChoices $questionnairesQuestionsAnwserChoices)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\QuestionnairesQuestionsAnwserChoices  $questionnairesQuestionsAnwserChoices
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, QuestionnairesQuestionsAnwserChoices $questionnairesQuestionsAnwserChoices)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\QuestionnairesQuestionsAnwserChoices  $questionnairesQuestionsAnwserChoices
     * @return \Illuminate\Http\Response
     */
    public function destroy(QuestionnairesQuestionsAnwserChoices $questionnairesQuestionsAnwserChoices)
    {
        //
    }
}
