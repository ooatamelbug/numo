<?php

namespace App\Http\Controllers;

use App\Models\ExamFinial;
use Illuminate\Http\Request;

class ExamFinialController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ExamFinial  $examFinial
     * @return \Illuminate\Http\Response
     */
    public function show(ExamFinial $examFinial)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ExamFinial  $examFinial
     * @return \Illuminate\Http\Response
     */
    public function edit(ExamFinial $examFinial)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ExamFinial  $examFinial
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExamFinial $examFinial)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ExamFinial  $examFinial
     * @return \Illuminate\Http\Response
     */
    public function destroy(ExamFinial $examFinial)
    {
        //
    }
}
