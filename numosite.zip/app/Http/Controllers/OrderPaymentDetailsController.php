<?php

namespace App\Http\Controllers;

use App\Models\OrderPaymentDetails;
use Illuminate\Http\Request;

class OrderPaymentDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\OrderPaymentDetails  $orderPaymentDetails
     * @return \Illuminate\Http\Response
     */
    public function show(OrderPaymentDetails $orderPaymentDetails)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\OrderPaymentDetails  $orderPaymentDetails
     * @return \Illuminate\Http\Response
     */
    public function edit(OrderPaymentDetails $orderPaymentDetails)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\OrderPaymentDetails  $orderPaymentDetails
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OrderPaymentDetails $orderPaymentDetails)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\OrderPaymentDetails  $orderPaymentDetails
     * @return \Illuminate\Http\Response
     */
    public function destroy(OrderPaymentDetails $orderPaymentDetails)
    {
        //
    }
}
