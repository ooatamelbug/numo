<?php

namespace App\Http\Controllers;

use App\Models\QuestionnairesQuestionsChoices;
use Illuminate\Http\Request;

class QuestionnairesQuestionsChoicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\QuestionnairesQuestionsChoices  $questionnairesQuestionsChoices
     * @return \Illuminate\Http\Response
     */
    public function show(QuestionnairesQuestionsChoices $questionnairesQuestionsChoices)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\QuestionnairesQuestionsChoices  $questionnairesQuestionsChoices
     * @return \Illuminate\Http\Response
     */
    public function edit(QuestionnairesQuestionsChoices $questionnairesQuestionsChoices)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\QuestionnairesQuestionsChoices  $questionnairesQuestionsChoices
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, QuestionnairesQuestionsChoices $questionnairesQuestionsChoices)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\QuestionnairesQuestionsChoices  $questionnairesQuestionsChoices
     * @return \Illuminate\Http\Response
     */
    public function destroy(QuestionnairesQuestionsChoices $questionnairesQuestionsChoices)
    {
        //
    }
}
