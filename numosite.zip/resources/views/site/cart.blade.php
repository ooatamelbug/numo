@extends('layouts.layout')

@section('content')
@endsection

@section('script')
<script>

</script>
@endsection
